#include "__fc_builtin.h"

int main(void){
  int i ;
  //@ ghost Frama_C_show_each(i);
  //@ ghost int p = Frama_C_int_interval(0, 10);
}
