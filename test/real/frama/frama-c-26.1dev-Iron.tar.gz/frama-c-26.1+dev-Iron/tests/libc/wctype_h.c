#include <wctype.h>

int main() {
  return WEOF;
}
