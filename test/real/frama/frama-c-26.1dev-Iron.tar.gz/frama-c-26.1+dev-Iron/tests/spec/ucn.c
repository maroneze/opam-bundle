/*@ lemma test_ucn: \U00002200 \U0001D539 b; b \u21D4 \u00AC \U000000AC b; */
