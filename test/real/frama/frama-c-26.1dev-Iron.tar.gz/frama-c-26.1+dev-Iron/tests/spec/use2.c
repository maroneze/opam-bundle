/* run.config
   DONTRUN: main test is in use.c
*/

#include "dec.h"

//@ ensures X > 0 ; ensures F(1)>0 ;
void g(void) {}
