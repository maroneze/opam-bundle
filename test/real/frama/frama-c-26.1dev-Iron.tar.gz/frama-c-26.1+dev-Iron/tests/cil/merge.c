/* run.config
   STDOPT: +"%{dep:./merge2.c}"
*/
extern int x;
