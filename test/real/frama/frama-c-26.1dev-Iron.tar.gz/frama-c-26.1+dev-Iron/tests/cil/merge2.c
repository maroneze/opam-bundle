/* run.config
   STDOPT: +"%{dep:./merge.c}"
 */
int x =2;
