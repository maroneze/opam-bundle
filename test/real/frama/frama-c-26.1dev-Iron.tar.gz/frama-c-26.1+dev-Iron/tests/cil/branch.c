/* run.config
   OPT:-print
*/

int f(int a,int b) {
  if (a<b)
    return a++ ;
  else
    return b-- ;
}
