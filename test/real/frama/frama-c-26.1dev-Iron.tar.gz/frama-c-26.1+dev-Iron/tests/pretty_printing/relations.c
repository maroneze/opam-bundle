/*@ predicate rel1(integer x, integer y, integer z, integer t) =
  x <= y <= z && z >= t;
 */

/*@ predicate rel2(integer x, integer y, integer z, integer t) =
  x <= y == z && z >= t;
 */
