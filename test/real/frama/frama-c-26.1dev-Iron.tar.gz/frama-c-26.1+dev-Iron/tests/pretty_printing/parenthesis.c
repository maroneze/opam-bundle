/* run.config
   OPT: -print
 */

/*@
  predicate implies(integer x,integer y) =
  (x == 0 ==> y == 0) ==> (x == 1 ==> y == 1);
  @*/
