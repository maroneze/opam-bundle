#include "features.h"
__PUSH_FC_STDLIB
struct { char z; unsigned long t; } s2;
enum { FOO, BAR=3 };
__POP_FC_STDLIB
