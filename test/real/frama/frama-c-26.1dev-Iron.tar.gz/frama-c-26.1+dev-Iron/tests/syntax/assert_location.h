#include "assert.h"

void h() {
  assert("I'm in assert_location.h");
}
