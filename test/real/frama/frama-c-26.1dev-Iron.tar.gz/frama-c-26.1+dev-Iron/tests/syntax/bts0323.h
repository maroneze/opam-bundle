extern int x;
/*@
  ensures x!=0;
*/
extern void g();
