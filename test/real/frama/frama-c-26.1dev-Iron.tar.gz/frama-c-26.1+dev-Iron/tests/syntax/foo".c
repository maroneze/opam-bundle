#include "assert.h"

int test = 1;

int main () {
  assert(test);
}
