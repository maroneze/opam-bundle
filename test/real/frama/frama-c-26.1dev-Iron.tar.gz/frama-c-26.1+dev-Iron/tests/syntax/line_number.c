/* run.config*
 EXIT: 1
   STDOPT:
*/

//@ assert \result == 0;
extern int p(void void);
