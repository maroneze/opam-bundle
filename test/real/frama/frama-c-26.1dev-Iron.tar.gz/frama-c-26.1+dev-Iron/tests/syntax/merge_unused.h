// decl.h
struct s {
  char c;
  int i;
};

extern struct s G1;

extern struct s G3;

extern int G2;
