//@ requires x < 10;
static f(int x);
