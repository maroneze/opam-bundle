/* run.config
 DEPS: assert_location.h
   STDOPT:
*/

#include "assert_location.h"

void c() {
  assert("I'm in assert_location.c");
}
