/* run.config
   DONTRUN: test run by main.c
*/

int
main2
(char *c, int i);

struct s {
  char c;
};

struct s **main3(
                 struct s *p1, struct s s2
                 ) {

}
