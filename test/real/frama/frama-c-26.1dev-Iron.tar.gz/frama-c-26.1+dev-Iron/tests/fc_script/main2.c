/* run.config
   DONTRUN:
   COMMENT: used by main.c
 */

void fake_main() {

}

void domain() {

}

void main2() {

}
