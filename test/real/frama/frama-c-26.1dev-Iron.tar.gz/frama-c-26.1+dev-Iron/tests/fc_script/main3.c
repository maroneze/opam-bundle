/* run.config
   DONTRUN:
   COMMENT: used by main.c
 */

int main( int argc, char *argv[] )
{

}
