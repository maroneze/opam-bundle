// to be included via '-include' in a JCDB

#define THREE 3
