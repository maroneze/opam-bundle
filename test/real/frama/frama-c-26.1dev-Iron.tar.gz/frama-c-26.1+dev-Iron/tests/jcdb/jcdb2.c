/* run.config
   DONTRUN:
   COMMENT: only used to test parsing of options in with_arguments.json
*/
