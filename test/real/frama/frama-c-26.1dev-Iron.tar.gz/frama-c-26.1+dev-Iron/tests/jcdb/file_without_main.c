/* run.config
DONTRUN:
*/

// declares but does not define main
void main(void);

// looks similar to main(), but isn't
void remain(void) {}
