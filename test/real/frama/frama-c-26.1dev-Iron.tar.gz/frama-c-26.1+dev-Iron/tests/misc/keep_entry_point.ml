let () = Rmtmps.rmUnusedStatic := true

let () = Kernel.feedback "Do not keep unused static functions"
