/* run.config
 MODULE: @PTEST_NAME@
  OPT: -no-autoload-plugins
*/

// Everything is done by the script
