let () = Db.Main.extend (fun () ->
    Kernel.feedback "module successfully loaded"
  )
